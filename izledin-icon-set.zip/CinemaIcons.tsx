import React from 'react';

export interface IconProps extends React.SVGProps<SVGSVGElement> {
  size?: number | string;
  className?: string;
}

/**
 * 35mm Brutalist Film Frame & Projector Eye Brand Glyph
 * Master Brand Icon for izledin.com from public/logo.svg
 */
export function CinemaLogoMark({ size = 32, className = '', ...props }: IconProps) {
  const numericSize = typeof size === 'number' ? size : parseInt(String(size), 10) || 32;
  const width = Math.round(numericSize * (296 / 206));

  return (
    <svg
      width={width}
      height={numericSize}
      viewBox="0 0 296 206"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      {/* Neobrutalist Hard Offset Shadow */}
      <path d="M18 22h278v184H18z" fill="#DC2626" />
      {/* 35mm Film Frame */}
      <rect x="0" y="0" width="278" height="184" className="fill-[#0A0A0A] stroke-[#0A0A0A] dark:stroke-[#404040]" strokeWidth="3" />
      {/* Sprocket Holes */}
      <g className="fill-[#FFFFFF]">
        <rect x="16" y="16" width="30" height="24" />
        <rect x="16" y="52" width="30" height="24" />
        <rect x="16" y="108" width="30" height="24" />
        <rect x="16" y="144" width="30" height="24" />
        <rect x="232" y="16" width="30" height="24" />
        <rect x="232" y="52" width="30" height="24" />
        <rect x="232" y="108" width="30" height="24" />
        <rect x="232" y="144" width="30" height="24" />
      </g>
      {/* Projector Eye */}
      <path d="M61 92C91 50 126 29 139 29s48 21 78 63c-30 42-65 63-78 63S91 134 61 92Z" fill="#FAFAFA" />
      {/* Iris */}
      <circle cx="139" cy="92" r="42" fill="#0A0A0A" />
      <circle cx="139" cy="92" r="33" fill="#DC2626" />
      {/* Play Symbol */}
      <path d="M130 72l28 20-28 20z" fill="#FFFFFF" />
      {/* Film-cut marks */}
      <path d="M0 80h10v24H0zM268 80h10v24h-10z" fill="#FFFFFF" />
    </svg>
  );
}

/**
 * Full Horizontal Vector Brand Logo for izledin.com from public/logo.svg
 * With dark mode adaptive typography.
 */
export function CinemaFullLogo({ height = 36, className = '', ...props }: React.SVGProps<SVGSVGElement> & { height?: number }) {
  const width = Math.round(height * (1200 / 360));
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 1200 360"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`inline-block ${className}`}
      {...props}
    >
      {/* ICON */}
      <g transform="translate(38 48)">
        <path d="M18 22h278v188H18z" fill="#DC2626" transform="translate(9 9)" />
        <rect x="0" y="0" width="278" height="188" fill="#0A0A0A" />
        <g fill="#FFFFFF">
          <rect x="16" y="16" width="30" height="24" />
          <rect x="16" y="52" width="30" height="24" />
          <rect x="16" y="112" width="30" height="24" />
          <rect x="16" y="148" width="30" height="24" />
          <rect x="232" y="16" width="30" height="24" />
          <rect x="232" y="52" width="30" height="24" />
          <rect x="232" y="112" width="30" height="24" />
          <rect x="232" y="148" width="30" height="24" />
        </g>
        <path d="M61 94C91 52 126 31 139 31s48 21 78 63c-30 42-65 63-78 63S91 136 61 94Z" fill="#FAFAFA" />
        <circle cx="139" cy="94" r="43" fill="#0A0A0A" />
        <circle cx="139" cy="94" r="34" fill="#DC2626" />
        <path d="M130 74l29 20-29 20z" fill="#FFFFFF" />
        <path d="M0 82h10v24H0zM268 82h10v24h-10z" fill="#FFFFFF" />
      </g>

      {/* WORDMARK */}
      <g font-family="var(--font-geist-sans), Arial, Helvetica, sans-serif" font-weight="900">
        <text x="355" y="184" font-size="128" letter-spacing="-6" className="fill-[#0A0A0A] dark:fill-[#FAFAFA]">izledin</text>
        <rect x="978" y="100" width="184" height="94" className="fill-[#0A0A0A] dark:fill-[#000000]" transform="translate(6 6)" />
        <rect x="970" y="92" width="184" height="94" fill="#DC2626" />
        <text x="986" y="163" font-size="62" letter-spacing="-2" fill="#FFFFFF">.com</text>
      </g>

      {/* DIVIDER */}
      <rect x="355" y="214" width="799" height="5" className="fill-[#0A0A0A] dark:fill-[#404040]" />
      <rect x="355" y="214" width="210" height="5" fill="#DC2626" />

      {/* MONO SIGNATURE */}
      <text
        x="355"
        y="255"
        font-family="var(--font-geist-mono), monospace"
        font-size="18"
        font-weight="800"
        letter-spacing="3.2"
        className="fill-[#525252] dark:fill-[#A3A3A3]"
      >
        İZLE · KAYDET · PAYLAŞ · TARTIŞ
      </text>

      {/* MICRO MARK */}
      <text
        x="1154"
        y="255"
        text-anchor="end"
        font-family="var(--font-geist-mono), monospace"
        font-size="14"
        font-weight="900"
        letter-spacing="1.5"
        fill="#DC2626"
      >
        CINE / SOCIAL / LOG
      </text>
    </svg>
  );
}

/**
 * 35mm Projector Beam (Gece Seansı / Dark Mode Glyph)
 * Carbon arc 35mm cinema projector projecting a luminous light beam.
 */
export function CinemaProjectorBeamIcon({ size = 20, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <circle cx="5" cy="5" r="2.5" />
      <circle cx="11" cy="5" r="2.5" />
      <rect x="2" y="8" width="11" height="9" rx="1" />
      <circle cx="7.5" cy="12.5" r="2" fill="currentColor" fillOpacity="0.25" />
      <path d="M13 11L15 10V15L13 14" fill="currentColor" />
      <polygon
        points="15,12.5 22,7 22,18"
        fill="currentColor"
        fillOpacity="0.2"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeDasharray="2 1.5"
      />
      <line x1="15" y1="12.5" x2="22" y2="12.5" strokeWidth="1.5" />
    </svg>
  );
}

/**
 * 35mm Day Aperture (Gündüz Matinesi / Light Mode Glyph)
 * Authentic 35mm optical iris diaphragm with radiant matinee sunburst geometry.
 */
export function CinemaDayApertureIcon({ size = 20, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <circle cx="12" cy="12" r="9" />
      <circle cx="12" cy="12" r="3.5" fill="currentColor" fillOpacity="0.25" />
      <path d="M12 3L15 8.5" />
      <path d="M19.8 7.5L16 12" />
      <path d="M19.8 16.5L14 15.5" />
      <path d="M12 21L9 15.5" />
      <path d="M4.2 16.5L8 12" />
      <path d="M4.2 7.5L10 8.5" />
      <circle cx="12" cy="12" r="1.5" fill="currentColor" />
    </svg>
  );
}

/**
 * 35mm Celluloid Film Reel
 */
export function FilmReelIcon({ size = 20, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <circle cx="12" cy="12" r="10" />
      <circle cx="12" cy="12" r="3" fill="currentColor" fillOpacity="0.2" />
      <circle cx="12" cy="5" r="1.5" fill="currentColor" />
      <circle cx="12" cy="19" r="1.5" fill="currentColor" />
      <circle cx="5" cy="12" r="1.5" fill="currentColor" />
      <circle cx="19" cy="12" r="1.5" fill="currentColor" />
      <line x1="12" y1="9" x2="12" y2="7" />
      <line x1="12" y1="17" x2="12" y2="15" />
      <line x1="9" y1="12" x2="7" y2="12" />
      <line x1="17" y1="12" x2="15" y2="12" />
    </svg>
  );
}

/**
 * Neobrutalist Cinema Clapperboard
 */
export function ClapperboardIcon({ size = 20, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <rect x="2" y="7" width="20" height="15" />
      <path d="M2 7L22 7L22 3L2 3Z" fill="currentColor" fillOpacity="0.15" />
      <path d="M6 3L9 7" />
      <path d="M12 3L15 7" />
      <path d="M18 3L21 7" />
      <circle cx="7" cy="14" r="1.5" fill="currentColor" />
      <line x1="11" y1="13" x2="18" y2="13" />
      <line x1="11" y1="16" x2="16" y2="16" />
    </svg>
  );
}

/**
 * Neobrutalist Cinema Admission Ticket Stub
 */
export function CinemaTicketIcon({ size = 20, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <path d="M2 9a3 3 0 0 1 0 6v5h20V4H2v5z" />
      <line x1="12" y1="5" x2="12" y2="7" strokeDasharray="1 1" />
      <line x1="12" y1="9" x2="12" y2="11" strokeDasharray="1 1" />
      <line x1="12" y1="13" x2="12" y2="15" strokeDasharray="1 1" />
      <line x1="12" y1="17" x2="12" y2="19" strokeDasharray="1 1" />
      <circle cx="7" cy="12" r="1.5" fill="currentColor" />
    </svg>
  );
}

/**
 * 35mm Celluloid Film Frame / Strip
 */
export function FilmStripIcon({ size = 20, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <rect x="2" y="3" width="20" height="18" />
      <rect x="7" y="6" width="10" height="12" fill="currentColor" fillOpacity="0.1" />
      <rect x="4" y="5" width="1.5" height="2" fill="currentColor" />
      <rect x="4" y="9" width="1.5" height="2" fill="currentColor" />
      <rect x="4" y="13" width="1.5" height="2" fill="currentColor" />
      <rect x="4" y="17" width="1.5" height="2" fill="currentColor" />
      <rect x="18.5" y="5" width="1.5" height="2" fill="currentColor" />
      <rect x="18.5" y="9" width="1.5" height="2" fill="currentColor" />
      <rect x="18.5" y="13" width="1.5" height="2" fill="currentColor" />
      <rect x="18.5" y="17" width="1.5" height="2" fill="currentColor" />
    </svg>
  );
}

/**
 * Cinema Search Lens Integrated with 35mm Reel
 */
export function CinemaSearchLensIcon({ size = 18, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <circle cx="10.5" cy="10.5" r="7.5" />
      <circle cx="10.5" cy="10.5" r="2.5" fill="currentColor" fillOpacity="0.2" />
      <line x1="16" y1="16" x2="22" y2="22" strokeWidth="3" />
      <rect x="9.5" y="4" width="2" height="1.5" fill="currentColor" />
      <rect x="9.5" y="15.5" width="2" height="1.5" fill="currentColor" />
    </svg>
  );
}

/**
 * Cinema Festival Laurel / Masterpiece Award
 */
export function MasterpieceLaurelIcon({ size = 20, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <path d="M4 18C3 13 4 8 8 4M4 11C6 11 8 9 8 7M3 15C5 15 7 14 8 12" />
      <path d="M20 18C21 13 20 8 16 4M20 11C18 11 16 9 16 7M21 15C19 15 17 14 16 12" />
      <polygon points="12 6 13.5 9 17 9.5 14.5 12 15 15.5 12 14 9 15.5 9.5 12 7 9.5 10.5 9" fill="currentColor" />
    </svg>
  );
}

/**
 * Cinema Hype Flame Vector Mark
 */
export function CinemaFlameIcon({ size = 20, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <path
        d="M12 2C9 6 6 9 6 14a6 6 0 0 0 12 0c0-3-1.5-6-3-8l-1 3-2-7z"
        fill="currentColor"
        fillOpacity="0.2"
      />
      <path d="M12 12c-1.5 1.5-2 3-2 4a2 2 0 0 0 4 0c0-1-.5-2-2-4z" fill="currentColor" />
    </svg>
  );
}

/**
 * Retro Cinema Popcorn Box
 */
export function CinemaPopcornIcon({ size = 20, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <path d="M5 9L7 21H17L19 9H5Z" />
      <line x1="9" y1="9" x2="10" y2="21" />
      <line x1="15" y1="9" x2="14" y2="21" />
      <path d="M5 9C4 7 5 5 7 5C8 3.5 10 3 12 4.5C14 3 16 3.5 17 5C19 5 20 7 19 9" fill="currentColor" fillOpacity="0.2" />
      <circle cx="9" cy="6" r="1.5" fill="currentColor" />
      <circle cx="15" cy="6" r="1.5" fill="currentColor" />
      <circle cx="12" cy="5" r="1.5" fill="currentColor" />
    </svg>
  );
}

/**
 * 35mm Carbon Arc Projector / Camera
 */
export function CinemaProjectorIcon({ size = 20, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <rect x="3" y="10" width="13" height="10" />
      <circle cx="6" cy="6" r="3" />
      <circle cx="13" cy="6" r="3" />
      <polygon points="16 12 21 9 21 21 16 18" fill="currentColor" fillOpacity="0.2" />
      <line x1="6" y1="6" x2="6" y2="10" />
      <line x1="13" y1="6" x2="13" y2="10" />
    </svg>
  );
}

/**
 * Cinema Trophy / Cannes Palme d'Or style emblem
 */
export function CinemaTrophyIcon({ size = 20, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <path d="M6 3H18V10C18 13.3 15.3 16 12 16C8.7 16 6 13.3 6 10V3Z" />
      <path d="M6 6H3C2 6 1 7 1 8C1 10.5 2.8 12.5 5.2 12.9" />
      <path d="M18 6H21C22 6 23 7 23 8C23 10.5 21.2 12.5 18.8 12.9" />
      <line x1="12" y1="16" x2="12" y2="20" />
      <line x1="7" y1="20" x2="17" y2="20" />
      <polygon points="12 6 13 8 15 8 13.5 9.5 14 11.5 12 10.5 10 11.5 10.5 9.5 9 8 11 8" fill="currentColor" />
    </svg>
  );
}

/**
 * Bespoke Chiseled 35mm Cinema Star
 * Authentic optical faceted geometry with center optical aperture.
 */
export function CinemaStarIcon({ size = 18, className = '', filled = true, ...props }: IconProps & { filled?: boolean }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      {/* 5-point Chiseled Star Silhouette */}
      <polygon
        points="12 2 15.2 8.5 22.3 9.5 17.2 14.5 18.4 21.6 12 18.2 5.6 21.6 6.8 14.5 1.7 9.5 8.8 8.5"
        fill={filled ? 'currentColor' : 'none'}
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinejoin="miter"
      />
      {/* Facet Light Lines */}
      {filled && (
        <path
          d="M12 2V18.2M22.3 9.5L12 18.2M1.7 9.5L12 18.2"
          stroke="currentColor"
          strokeWidth="0.75"
          strokeOpacity="0.35"
        />
      )}
      {/* Center Optical Aperture Point */}
      <circle cx="12" cy="12.5" r="1.2" className={filled ? 'fill-[#0A0A0A] dark:fill-[#000000]' : 'fill-currentColor'} />
    </svg>
  );
}

/**
 * 4-Point Swiss Celluloid Sparkle
 */
export function SwissSparkleIcon({ size = 18, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="currentColor"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <path d="M12 0L14.5 9.5L24 12L14.5 14.5L12 24L9.5 14.5L0 12L9.5 9.5L12 0Z" />
    </svg>
  );
}

/**
 * Bespoke Cinema VIP Pass / Ticket Badge (izledin+)
 * Features a tactile celluloid ticket notch profile with a stylized '+' film aperture spark
 */
export function CinemaPlusPassIcon({ size = 20, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      {/* Celluloid Ticket Silhouette with side notches */}
      <path
        d="M3 4H21V9C19.34 9 18 10.34 18 12C18 13.66 19.34 15 21 15V20H3V15C4.66 15 6 13.66 6 12C6 10.34 4.66 9 3 9V4Z"
        fill="currentColor"
        fillOpacity="0.15"
      />
      {/* Stylized '+' Film Aperture Center Spark */}
      <path d="M12 8.5V15.5" strokeWidth="2.5" />
      <path d="M8.5 12H15.5" strokeWidth="2.5" />
      <circle cx="12" cy="12" r="1" fill="currentColor" />
      {/* 4 Corner 35mm Celluloid Perforations */}
      <rect x="5.5" y="5.5" width="1.5" height="1.5" fill="currentColor" stroke="none" />
      <rect x="17" y="5.5" width="1.5" height="1.5" fill="currentColor" stroke="none" />
      <rect x="5.5" y="17" width="1.5" height="1.5" fill="currentColor" stroke="none" />
      <rect x="17" y="17" width="1.5" height="1.5" fill="currentColor" stroke="none" />
    </svg>
  );
}

/**
 * @deprecated Use CinemaPlusPassIcon instead
 */
export const CinemaCrownIcon = CinemaPlusPassIcon;

/**
 * Cinema Heart with Perforation Notches
 */
export function CinemaHeartIcon({ size = 20, className = '', filled = false, ...props }: IconProps & { filled?: boolean }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill={filled ? 'currentColor' : 'none'}
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
      <line x1="12" y1="9" x2="12" y2="14" strokeWidth="1.5" />
    </svg>
  );
}

/**
 * Cinema Chat Speech Bubble with Film Cell Geometry
 */
export function CinemaChatIcon({ size = 20, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
      <line x1="8" y1="9" x2="16" y2="9" />
      <line x1="8" y1="13" x2="13" y2="13" />
    </svg>
  );
}

/**
 * Cinema Frequency / Waveform Radar
 */
export function CinemaFrequencyIcon({ size = 20, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <path d="M2 12h3l2-6 4 14 3-10 2 4h6" />
      <circle cx="2" cy="12" r="1" fill="currentColor" />
      <circle cx="22" cy="12" r="1" fill="currentColor" />
    </svg>
  );
}

/**
 * Cinema Calendar Date Stamp
 */
export function CinemaCalendarIcon({ size = 20, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <rect x="3" y="4" width="18" height="18" />
      <line x1="16" y1="2" x2="16" y2="6" />
      <line x1="8" y1="2" x2="8" y2="6" />
      <line x1="3" y1="10" x2="21" y2="10" />
      <rect x="7" y="14" width="3" height="3" fill="currentColor" />
      <rect x="14" y="14" width="3" height="3" fill="currentColor" />
    </svg>
  );
}

/**
 * Cinema User Profile Silhouette with 35mm Aperture
 */
export function CinemaUserIcon({ size = 20, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
      <circle cx="12" cy="7" r="4" />
      <circle cx="12" cy="7" r="1.5" fill="currentColor" />
    </svg>
  );
}

/**
 * 35mm Celluloid Quote Quotation Marks
 */
export function CinemaQuoteIcon({ size = 20, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="currentColor"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <path d="M10 11H6a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h4v5zm0 0v5a3 3 0 0 1-3 3H5m14-8h-4a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h4v5zm0 0v5a3 3 0 0 1-3 3h-2" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="square" />
    </svg>
  );
}

/**
 * Cinema Shield / 256-bit SSL Security Lock
 */
export function CinemaShieldIcon({ size = 20, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
      <circle cx="12" cy="11" r="2" fill="currentColor" />
      <line x1="12" y1="13" x2="12" y2="16" />
    </svg>
  );
}

/**
 * Cinema Certified / Verified Seal
 */
export function CinemaVerifiedSeal({ size = 20, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <polygon points="12 2 15 5 19 5 20 9 23 12 20 15 19 19 15 19 12 22 9 19 5 19 4 15 1 12 4 9 5 5 9 5" fill="currentColor" fillOpacity="0.15" />
      <polyline points="9 12 11 14 15 10" />
    </svg>
  );
}

/**
 * Cinema Neobrutalist Checkmark
 */
export function CinemaCheckIcon({ size = 16, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}

/**
 * izledin+ Custom Brand Badge / Ticket Stamp
 */
export function IzledinPlusBadge({ className = '', size = 'md' }: { className?: string; size?: 'sm' | 'md' | 'lg' }) {
  const sizeClasses = {
    sm: 'px-1.5 py-0.5 text-[10px] gap-1 border',
    md: 'px-2 py-0.5 text-[11px] gap-1.5 border-2',
    lg: 'px-3 py-1 text-xs gap-2 border-2',
  }[size];

  return (
    <span
      className={`inline-flex items-center ${sizeClasses} border-[#DC2626] dark:border-[#EF4444] bg-[#DC2626]/10 dark:bg-[#EF4444]/15 text-[#DC2626] dark:text-[#EF4444] font-mono font-black tracking-wider uppercase shadow-[2px_2px_0px_#0A0A0A] dark:shadow-[2px_2px_0px_#000000] select-none ${className}`}
    >
      <CinemaPlusPassIcon size={size === 'sm' ? 11 : size === 'lg' ? 15 : 13} className="text-[#DC2626] dark:text-[#EF4444]" />
      <span>IZLEDIN<span className="text-[#DC2626] dark:text-[#EF4444]">+</span></span>
    </span>
  );
}

/**
 * Authentic 35mm Analog Projector Gate & Optical Shutter Scanner Illustration
 * Replaces generic military sonar radars with an authentic 35mm film projector lens & celluloid gate.
 * Features 35mm side sprocket holes, 24 FPS calibration, rotating 3-blade shutter, and xenon light beam.
 */
export function CinemaRadarScannerIllustration({ 
  size = 72, 
  className = '',
  ...props 
}: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 96 96"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <style>{`
        @keyframes cinema-shutter-rotate {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes cinema-beam-pulse {
          0%, 100% { opacity: 0.25; transform: scale(1); }
          50% { opacity: 0.55; transform: scale(1.04); }
        }
        @keyframes cinema-lens-glow {
          0%, 100% { fill-opacity: 0.9; }
          50% { fill-opacity: 0.4; }
        }
        .anim-shutter {
          transform-origin: 48px 48px;
          animation: cinema-shutter-rotate 8s linear infinite;
        }
        .anim-beam {
          transform-origin: 48px 48px;
          animation: cinema-beam-pulse 2.4s ease-in-out infinite;
        }
        .anim-lamp {
          animation: cinema-lens-glow 1.8s ease-in-out infinite;
        }
      `}</style>

      {/* 1. Outer 35mm Celluloid Frame Housing */}
      <rect
        x="6"
        y="6"
        width="84"
        height="84"
        className="fill-[#0A0A0A] stroke-[#0A0A0A] dark:stroke-[#404040]"
        strokeWidth="2.5"
      />

      {/* 2. Top & Bottom 35mm Sprocket Perforation Holes */}
      <g className="fill-[#FFFFFF] dark:fill-[#262626]">
        {/* Left Sprocket Strip */}
        <rect x="10" y="14" width="6" height="8" rx="0.5" />
        <rect x="10" y="28" width="6" height="8" rx="0.5" />
        <rect x="10" y="44" width="6" height="8" rx="0.5" />
        <rect x="10" y="60" width="6" height="8" rx="0.5" />
        <rect x="10" y="74" width="6" height="8" rx="0.5" />

        {/* Right Sprocket Strip */}
        <rect x="80" y="14" width="6" height="8" rx="0.5" />
        <rect x="80" y="28" width="6" height="8" rx="0.5" />
        <rect x="80" y="44" width="6" height="8" rx="0.5" />
        <rect x="80" y="60" width="6" height="8" rx="0.5" />
        <rect x="80" y="74" width="6" height="8" rx="0.5" />
      </g>

      {/* 3. Central Cinema Projection Chamber (Circular Lens Barrel) */}
      <circle
        cx="48"
        cy="48"
        r="28"
        className="fill-[#141414] stroke-[#DC2626] dark:stroke-[#EF4444]"
        strokeWidth="2"
      />

      {/* 4. Optical Sound Track Calibration Grid (Subtle Inner Circle) */}
      <circle
        cx="48"
        cy="48"
        r="21"
        className="stroke-[#DC2626]/40 dark:stroke-[#EF4444]/40"
        strokeWidth="1"
        strokeDasharray="2 3"
      />

      {/* 5. Projector Light Beam (Pulsing Optical Beam) */}
      <path
        d="M48 48 L70 28 A28 28 0 0 0 48 20 Z"
        className="fill-[#DC2626]/30 dark:fill-[#EF4444]/35 anim-beam"
      />

      {/* 6. Rotating 35mm Shutter Mechanism */}
      <g className="anim-shutter">
        {/* Shutter Blade 1 */}
        <line x1="48" y1="48" x2="48" y2="22" className="stroke-[#DC2626] dark:stroke-[#EF4444]" strokeWidth="2" strokeLinecap="square" />
        {/* Shutter Blade 2 (120 deg) */}
        <line x1="48" y1="48" x2="70.5" y2="61" className="stroke-[#DC2626] dark:stroke-[#EF4444]" strokeWidth="2" strokeLinecap="square" />
        {/* Shutter Blade 3 (240 deg) */}
        <line x1="48" y1="48" x2="25.5" y2="61" className="stroke-[#DC2626] dark:stroke-[#EF4444]" strokeWidth="2" strokeLinecap="square" />

        {/* 35mm Shutter Weight Knobs */}
        <circle cx="48" cy="24" r="2.5" className="fill-[#F59E0B] dark:fill-[#FBBF24]" />
        <circle cx="68.5" cy="59.5" r="2.5" className="fill-[#F59E0B] dark:fill-[#FBBF24]" />
        <circle cx="27.5" cy="59.5" r="2.5" className="fill-[#F59E0B] dark:fill-[#FBBF24]" />
      </g>

      {/* 7. Central Xenon Arc Projector Lamp (Lens Core) */}
      <circle cx="48" cy="48" r="6" className="fill-[#0A0A0A] stroke-[#FFFFFF] dark:stroke-[#FAFAFA]" strokeWidth="1.5" />
      <circle cx="48" cy="48" r="3.5" className="fill-[#DC2626] dark:fill-[#EF4444] anim-lamp" />

      {/* 8. 35MM / 24 FPS Cinema Typography Badges */}
      <text
        x="48"
        y="11"
        textAnchor="middle"
        className="fill-[#A3A3A3] dark:fill-[#737373]"
        fontSize="5"
        fontWeight="900"
        fontFamily="monospace"
        letterSpacing="0.1em"
      >
        35MM // 24 FPS
      </text>

      <text
        x="48"
        y="89"
        textAnchor="middle"
        className="fill-[#DC2626] dark:fill-[#EF4444]"
        fontSize="4.5"
        fontWeight="900"
        fontFamily="monospace"
        letterSpacing="0.08em"
      >
        İZDAŞ RADARI
      </text>
    </svg>
  );
}

/**
 * Handcrafted 35mm Twin Cinema Reels (Film Arkadaşlığı / Platonik Sinefil)
 */
export function CinemaFriendshipIcon({ size = 18, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <circle cx="8" cy="12" r="6" />
      <circle cx="16" cy="12" r="6" />
      <circle cx="8" cy="12" r="2" fill="currentColor" fillOpacity="0.2" />
      <circle cx="16" cy="12" r="2" fill="currentColor" fillOpacity="0.2" />
      <line x1="8" y1="6" x2="16" y2="6" strokeWidth="2" />
      <line x1="8" y1="18" x2="16" y2="18" strokeWidth="2" />
    </svg>
  );
}

/**
 * Handcrafted Geometric Cinema Heart (Sinematik Flört & İlişki)
 */
export function CinemaRomanceIcon({ size = 18, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <path
        d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"
      />
      <circle cx="8" cy="8" r="1.5" fill="currentColor" />
      <circle cx="16" cy="8" r="1.5" fill="currentColor" />
      <line x1="12" y1="11" x2="12" y2="16" strokeWidth="1.5" strokeDasharray="1 1" />
    </svg>
  );
}

/**
 * Handcrafted Dual Ticket Stubs (Her İkisi / Geniş Sinefil Frekansı)
 */
export function CinemaDuoIntentIcon({ size = 18, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <rect x="3" y="5" width="14" height="10" rx="1" />
      <path d="M7 15v4h14V9h-4" />
      <circle cx="6" cy="10" r="1" fill="currentColor" />
      <circle cx="14" cy="10" r="1" fill="currentColor" />
      <line x1="10" y1="7" x2="10" y2="13" strokeWidth="1.5" strokeDasharray="1 1" />
    </svg>
  );
}

/**
 * Handcrafted Cinema Trust Shield with Verification Mark
 */
export function CinemaTrustShieldIcon({ size = 16, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <path d="M12 2L4 5v6.5c0 5 3.4 9.7 8 10.5 4.6-.8 8-5.5 8-10.5V5l-8-3z" />
      <path d="M9 12l2 2 4-4" strokeWidth="2.5" />
    </svg>
  );
}

/**
 * Handcrafted 35mm Celluloid Slide Deck Stack Icon
 */
export function CinemaDeckStackIcon({ size = 18, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <rect x="6" y="2" width="14" height="15" />
      <rect x="4" y="5" width="14" height="15" className="fill-[#FAFAFA] dark:fill-[#171717]" />
      <rect x="2" y="8" width="14" height="15" />
      <rect x="5" y="11" width="8" height="9" fill="currentColor" fillOpacity="0.15" />
    </svg>
  );
}

/**
 * Handcrafted Director Contact Sheet Matrix Icon
 */
export function CinemaGridMatrixIcon({ size = 18, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      <rect x="3" y="3" width="7" height="7" />
      <rect x="14" y="3" width="7" height="7" />
      <rect x="3" y="14" width="7" height="7" />
      <rect x="14" y="14" width="7" height="7" />
    </svg>
  );
}

/**
 * 35mm Film Strip & Cinephile DNA Double Helix Glyph
 * Replaces generic AI sparkle icons on Taste Profiler & Cinema DNA Calibrator.
 */
export function CinemaDnaHelixIcon({ size = 18, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      {/* 35mm Film Strand 1 */}
      <path d="M4 3c4 6 12 12 16 18" strokeWidth="2" />
      {/* 35mm Film Strand 2 */}
      <path d="M20 3C16 9 8 15 4 21" strokeWidth="2" />
      {/* Sprocket Cross Rungs / Base Pairs */}
      <path d="M7 6.5h10" strokeWidth="1.5" />
      <path d="M10 12h4" strokeWidth="2.5" />
      <path d="M7 17.5h10" strokeWidth="1.5" />
      {/* Celluloid Node Dots */}
      <rect x="3" y="2" width="2" height="2" fill="currentColor" />
      <rect x="19" y="2" width="2" height="2" fill="currentColor" />
      <rect x="3" y="20" width="2" height="2" fill="currentColor" />
      <rect x="19" y="20" width="2" height="2" fill="currentColor" />
    </svg>
  );
}

/**
 * 35mm Admission Notch VIP Pass Ticket Icon
 * Replaces generic AI sparkles on 30-Day Free Trial & Premium CTA.
 */
export function CinemaPassTicketIcon({ size = 18, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      {/* Ticket Body with Notched Perforations */}
      <path d="M2 9a3 3 0 0 1 0-6h20a3 3 0 0 1 0 6v6a3 3 0 0 1 0 6H2a3 3 0 0 1 0-6V9z" />
      {/* Perforation Center Cut */}
      <path d="M12 3v3M12 18v3M12 9v6" strokeDasharray="2 2" strokeWidth="1.5" />
      {/* 35mm Star Admission Punch */}
      <circle cx="8" cy="12" r="2" fill="currentColor" />
      <circle cx="16" cy="12" r="2" fill="currentColor" />
    </svg>
  );
}

/**
 * 35mm Radar Sonar Frequency Sweep Icon
 * Replaces generic AI sparkles on İzdaş matching & similarity calculations.
 */
export function CinemaRadarSweepIcon({ size = 18, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      {/* 35mm Lens Outer Rim */}
      <circle cx="12" cy="12" r="9" />
      {/* Optical Projector Light Beam Cone */}
      <path d="M12 12l6.5-6.5A9 9 0 0 0 12 3v9z" fill="currentColor" fillOpacity="0.2" />
      <line x1="12" y1="12" x2="18.5" y2="5.5" strokeWidth="2" />
      {/* Xenon Bulb Core */}
      <circle cx="12" cy="12" r="2" fill="currentColor" />
      {/* 35mm Sprocket Notch Ticks */}
      <rect x="2" y="11" width="2" height="2" fill="currentColor" />
      <rect x="20" y="11" width="2" height="2" fill="currentColor" />
    </svg>
  );
}

/**
 * 35mm Projector Arc Lamp Lens Sparkle Glyph
 * Bespoke geometric projector lens aperture highlight.
 */
export function CinemaCelluloidSparkIcon({ size = 18, className = '', ...props }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="square"
      strokeLinejoin="miter"
      className={`inline-block shrink-0 ${className}`}
      {...props}
    >
      {/* Central 35mm Aperture Diamond */}
      <path d="M12 2l2.5 7.5L22 12l-7.5 2.5L12 22l-2.5-7.5L2 12l7.5-2.5L12 2z" fill="currentColor" fillOpacity="0.15" />
      {/* Secondary Projector Beam Points */}
      <circle cx="12" cy="12" r="2" fill="currentColor" />
      <path d="M18 4l1 3 3 1-3 1-1 3-1-3-3-1 3-1 1-3z" strokeWidth="1.5" />
    </svg>
  );
}


