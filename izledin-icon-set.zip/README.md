﻿# 🎬 izledin.com — 35mm Analog Sinema İkon Seti

Bu arşiv, **izledin.com** için sıfırdan elle tasarlanmış 38 adet özel SVG React ikonunu ve nerede kullanıldıklarını listeleyen detaylı kullanım kılavuzunu içermektedir.

## 📂 Arşiv İçeriği:
1. **CinemaIcons.tsx**: Tüm ikonların React SVG JSX bileşenlerini içeren TypeScript kaynak kodu.
2. **IKONLAR_VE_KULLANIM_REHBERI.txt**: Her ikonun hangi sayfalarda, modalarda ve bileşenlerde kullanıldığının tam haritası.

## 🎨 Tasarım Dili:
- **Tasarım Sistemi:** Gece Gösterimi (35mm Analog Fanzine)
- **Renk Paleti:** Velvet Cinema Red (#DC2626 / #EF4444), Amber Gold (#F59E0B / #FBBF24), Pure Obsidian (#0A0A0A)
- **Çizim Standardı:** 2px Neobrutalist Stroke, Monospace / Geist Sans tipografi, 35mm selüloit perfore detayları.
