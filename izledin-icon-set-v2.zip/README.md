﻿# 🎬 izledin.com — V2 35mm Modernist Sinema İkon Seti

Bu arşiv, **izledin.com** için 24x24 grid, 2px monoline, square terminal standartlarında hazırlanmış V2 modern 35mm sinema SVG ikon sistemini içermektedir.

## 📂 Arşiv İçeriği:
1. **CinemaIcons.tsx**: V2 Modernist Sinema İkon Sistemi React SVG JSX bileşenleri.
2. **IKONLAR_VE_KULLANIM_REHBERI.txt**: Her ikonun hangi sayfalarda, modalarda ve bileşenlerde kullanıldığının tam haritası.
